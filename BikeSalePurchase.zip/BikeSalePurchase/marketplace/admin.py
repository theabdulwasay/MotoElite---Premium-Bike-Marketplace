from django.contrib import admin
from .models import Bike, Inquiry

@admin.register(Bike)
class BikeAdmin(admin.ModelAdmin):
    list_display = ('brand', 'model_name', 'year', 'price', 'created_at')
    search_fields = ('brand', 'model_name')
    list_filter = ('brand', 'year')

@admin.register(Inquiry)
class InquiryAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'subject', 'created_at')
    search_fields = ('name', 'email', 'subject')
