from django.core.management.base import BaseCommand
from marketplace.models import Bike, Inquiry
from django.utils import timezone
import random

class Command(BaseCommand):
    help = 'Populates the database with sample bike data'

    def handle(self, *args, **kwargs):
        self.stdout.write('Populating data...')
        
        # Clear existing data
        Bike.objects.all().delete()
        Inquiry.objects.all().delete()

        bikes_data = [
            # Sport Bikes
            {'brand': 'Kawasaki', 'model_name': 'Ninja ZX-10R', 'year': 2024, 'price': 17399, 'mileage': 0, 'description': 'Sport. The Ninja ZX-10R has a dual injection system that provides a fine mist of fuel from the secondary injectors at high engine speeds for increased top-end power.', 'image_url': 'https://images.unsplash.com/photo-1558981403-c5f91cb9c238?auto=format&fit=crop&q=80&w=800'},
            {'brand': 'Ducati', 'model_name': 'Panigale V4', 'year': 2023, 'price': 24495, 'mileage': 500, 'description': 'Sport. A masterpiece of Italian engineering and design, the Panigale V4 is the closest thing to a MotoGP bike for the road.', 'image_url': 'https://images.unsplash.com/photo-1542362567-b052ef13459c?auto=format&fit=crop&q=80&w=800'},
            {'brand': 'BMW', 'model_name': 'S 1000 RR', 'year': 2024, 'price': 18295, 'mileage': 0, 'description': 'Sport. The BMW S 1000 RR is a sport bike initially made by BMW Motorrad to compete in the 2009 Superbike World Championship.', 'image_url': 'https://images.unsplash.com/photo-1614165933833-87ddcc4a15a2?auto=format&fit=crop&q=80&w=800'},
            {'brand': 'Yamaha', 'model_name': 'YZF-R1', 'year': 2022, 'price': 15500, 'mileage': 1200, 'description': 'Sport. The R1 features a crossplane crankshaft engine that delivers linear torque for incredible traction.', 'image_url': 'https://images.unsplash.com/photo-1449491026413-9c4f96446580?auto=format&fit=crop&q=80&w=800'},
            {'brand': 'Suzuki', 'model_name': 'GSX-R1000R', 'year': 2023, 'price': 16199, 'mileage': 150, 'description': 'Sport. The King of Sportbikes is back with advanced aerodynamics and engine technology derived from MotoGP.', 'image_url': 'https://images.unsplash.com/photo-1558981359-219d6364c9c8?auto=format&fit=crop&q=80&w=800'},
            
            # Cruisers
            {'brand': 'Harley-Davidson', 'model_name': 'Iron 883', 'year': 2022, 'price': 9499, 'mileage': 1200, 'description': 'Cruiser. An urban icon, the Iron 883 is a stripped-down, blacked-out custom bike with a raw, gritty style.', 'image_url': 'https://images.unsplash.com/photo-1558981403-c5f91cb9c238?auto=format&fit=crop&q=80&w=800'},
            {'brand': 'Indian', 'model_name': 'Scout Bobber', 'year': 2023, 'price': 13499, 'mileage': 450, 'description': 'Cruiser. Slammed stance, chopped fenders, and knobby tires make this a true modern bobber.', 'image_url': 'https://images.unsplash.com/photo-1558981403-c5f91cb9c238?auto=format&fit=crop&q=80&w=800'},
            {'brand': 'Triumph', 'model_name': 'Bonneville Speedmaster', 'year': 2021, 'price': 11800, 'mileage': 3200, 'description': 'Cruiser. Classic British custom style with modern performance and sophisticated rider technology.', 'image_url': 'https://images.unsplash.com/photo-1542362567-b052ef13459c?auto=format&fit=crop&q=80&w=800'},
            {'brand': 'Honda', 'model_name': 'Rebel 1100', 'year': 2024, 'price': 9999, 'mileage': 0, 'description': 'Cruiser. The Rebel 1100 combines classic styling with a powerful parallel-twin engine and advanced electronics.', 'image_url': 'https://images.unsplash.com/photo-1614165933833-87ddcc4a15a2?auto=format&fit=crop&q=80&w=800'},
            
            # Adventure
            {'brand': 'KTM', 'model_name': '1290 Super Adventure R', 'year': 2023, 'price': 20299, 'mileage': 800, 'description': 'Adventure. Unstoppable off-road performance meets long-distance touring comfort.', 'image_url': 'https://images.unsplash.com/photo-1598211686238-15c0141da92d?auto=format&fit=crop&q=80&w=800'},
            {'brand': 'Honda', 'model_name': 'Africa Twin', 'year': 2022, 'price': 14399, 'mileage': 4500, 'description': 'Adventure. The ultimate adventure companion, ready for any terrain from tarmac to trail.', 'image_url': 'https://images.unsplash.com/photo-1558981359-219d6364c9c8?auto=format&fit=crop&q=80&w=800'},
            {'brand': 'Yamaha', 'model_name': 'Tenere 700', 'year': 2024, 'price': 10799, 'mileage': 0, 'description': 'Adventure. Lightweight, agile, and incredibly durable adventure bike for the serious explorer.', 'image_url': 'https://images.unsplash.com/photo-1449491026413-9c4f96446580?auto=format&fit=crop&q=80&w=800'},
            
            # Vintage/Others
            {'brand': 'Husqvarna', 'model_name': 'Vitpilen 401', 'year': 2022, 'price': 5399, 'mileage': 800, 'description': 'A fresh perspective on urban motorcycling, combining simple, progressive design with performance.', 'image_url': 'https://images.unsplash.com/photo-1558981403-c5f91cb9c238?auto=format&fit=crop&q=80&w=600'},
            {'brand': 'Aprilia', 'model_name': 'RS 660', 'year': 2024, 'price': 11499, 'mileage': 0, 'description': 'The RS 660 is the perfect balance between performance and comfort, a true Italian sportbike.', 'image_url': 'https://images.unsplash.com/photo-1622340578631-f925b6a7102e?auto=format&fit=crop&q=80&w=600'},

        ]

        for data in bikes_data:
            Bike.objects.create(**data)

        self.stdout.write(self.style.SUCCESS(f'Successfully added {len(bikes_data)} bikes.'))

        inquiries = [
            {'name': 'Ali Khan', 'email': 'ali@example.com', 'subject': 'Kawasaki Ninja ZX-10R', 'message': 'Is the price negotiable?'},
            {'name': 'Sarah Ahmed', 'email': 'sarah@example.com', 'subject': 'Ducati Panigale V4', 'message': 'I want to see the bike in person.'},
            {'name': 'Zeeshan Malik', 'email': 'zeeshan@example.com', 'subject': 'BMW S 1000 RR', 'message': 'What is the warranty period?'},
        ]

        for data in inquiries:
            Inquiry.objects.create(**data)

        self.stdout.write(self.style.SUCCESS(f'Successfully added {len(inquiries)} inquiries.'))
