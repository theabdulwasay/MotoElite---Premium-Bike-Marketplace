from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    BikeViewSet, InquiryViewSet, index, inventory, 
    details, contact, sell, admin_dashboard, admin_auth,
    customer_signup, customer_login, customer_logout, customer_dashboard
)

router = DefaultRouter()
router.register(r'bikes', BikeViewSet)
router.register(r'inquiries', InquiryViewSet)

urlpatterns = [
    path('', index, name='index'),
    path('inventory.html', inventory, name='inventory'),
    path('details.html', details, name='details'),
    path('details/<int:pk>/', details, name='bike_details'),

    path('contact.html', contact, name='contact'),
    path('sell.html', sell, name='sell'),
    
    # Customer Dashboard & Auth
    path('signup/', customer_signup, name='customer_signup'),
    path('login/', customer_login, name='customer_login'),
    path('logout/', customer_logout, name='customer_logout'),
    path('dashboard/', customer_dashboard, name='customer_dashboard'),

    path('admin.html', admin_dashboard, name='admin_dashboard'),
    path('admin-auth.html', admin_auth, name='admin_auth'),
    path('api/', include(router.urls)),
]
