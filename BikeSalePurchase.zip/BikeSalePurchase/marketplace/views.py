from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from rest_framework import viewsets
from .models import Bike, Inquiry
from .serializers import BikeSerializer, InquirySerializer

class BikeViewSet(viewsets.ModelViewSet):
    queryset = Bike.objects.all()
    serializer_class = BikeSerializer

class InquiryViewSet(viewsets.ModelViewSet):
    queryset = Inquiry.objects.all()
    serializer_class = InquirySerializer


def index(request):
    featured_bikes = Bike.objects.order_by('-created_at')[:3]
    return render(request, 'marketplace/index.html', {'bikes': featured_bikes})

def inventory(request):
    bikes = Bike.objects.all().order_by('-created_at')
    
    category = request.GET.get('category')
    if category:
        bikes = bikes.filter(description__icontains=category) | bikes.filter(brand__icontains=category)
    
    price_range = request.GET.get('price_range')
    if price_range:
        if price_range == '0-10000':
            bikes = bikes.filter(price__lt=10000)
        elif price_range == '10000-25000':
            bikes = bikes.filter(price__gte=10000, price__lte=25000)
        elif price_range == '25000+':
            bikes = bikes.filter(price__gt=25000)
            
    return render(request, 'marketplace/inventory.html', {'bikes': bikes})


def details(request, pk=None):
    if pk:
        bike = Bike.objects.get(pk=pk)
    else:
        # Fallback for the static link if no ID provided
        bike = Bike.objects.first()
    return render(request, 'marketplace/details.html', {'bike': bike})

def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        bike_id = request.POST.get('bike_id')
        
        bike = None
        if bike_id:
            bike = Bike.objects.get(id=bike_id)
            
        Inquiry.objects.create(
            name=name, email=email, subject=subject, 
            message=message, sender=request.user if request.user.is_authenticated else None,
            bike=bike
        )
        return render(request, 'marketplace/contact.html', {'success': True})
    return render(request, 'marketplace/contact.html')

def sell(request):
    if request.method == 'POST':
        brand = request.POST.get('brand')
        model_name = request.POST.get('model_name')
        year = request.POST.get('year')
        price = request.POST.get('price')
        mileage = request.POST.get('mileage')
        description = request.POST.get('description')
        image_url = request.POST.get('image_url')
        
        Bike.objects.create(
            brand=brand, model_name=model_name, year=year, 
            price=price, mileage=mileage, description=description,
            image_url=image_url,
            seller=request.user if request.user.is_authenticated else None
        )
        return render(request, 'marketplace/sell.html', {'success': True})
    return render(request, 'marketplace/sell.html')

def admin_dashboard(request):
    bikes = Bike.objects.all().order_by('-created_at')
    inquiries = Inquiry.objects.all().order_by('-created_at')
    return render(request, 'marketplace/admin.html', {
        'bikes': bikes,
        'inquiries': inquiries
    })

def admin_auth(request):
    return render(request, 'marketplace/admin-auth.html')

def customer_signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('customer_dashboard')
    else:
        form = UserCreationForm()
    return render(request, 'marketplace/customer-auth.html', {'form': form, 'mode': 'signup'})

def customer_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('customer_dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'marketplace/customer-auth.html', {'form': form, 'mode': 'login'})

def customer_logout(request):
    logout(request)
    return redirect('index')

@login_required(login_url='customer_login')
def customer_dashboard(request):
    user_bikes = Bike.objects.filter(seller=request.user).order_by('-created_at')
    user_inquiries = Inquiry.objects.filter(sender=request.user).order_by('-created_at')
    # Also get inquiries received on user's bikes
    received_inquiries = Inquiry.objects.filter(bike__seller=request.user).order_by('-created_at')
    
    return render(request, 'marketplace/customer-dashboard.html', {
        'bikes': user_bikes,
        'sent_inquiries': user_inquiries,
        'received_inquiries': received_inquiries
    })

