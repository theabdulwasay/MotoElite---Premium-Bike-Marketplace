const API_BASE = '/api';

document.addEventListener('DOMContentLoaded', () => {
    // Navbar Scroll Effect
    const nav = document.querySelector('nav');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            nav.classList.add('scrolled');
        } else {
            nav.classList.remove('scrolled');
        }
    });

    // Mobile Menu Toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', () => {
            menuToggle.classList.toggle('active');
            navLinks.classList.toggle('active');
            document.body.classList.toggle('overflow-hidden');
        });

        // Close menu when a link is clicked
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                menuToggle.classList.remove('active');
                navLinks.classList.remove('active');
                document.body.classList.remove('overflow-hidden');
            });
        });
    }

    // Scroll Reveal Animation
    const revealElements = document.querySelectorAll('.reveal');
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                revealObserver.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });

    revealElements.forEach(el => revealObserver.observe(el));

    // --- Form Handling ---

    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = contactForm.querySelector('button[type="submit"]');
            const originalText = btn.innerText;

            const formData = new FormData(contactForm);
            const data = Object.fromEntries(formData.entries());

            btn.disabled = true;
            btn.innerText = 'Sending...';

            try {
                const response = await fetch(`${API_BASE}/inquiries/`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': getCookie('csrftoken')
                    },
                    body: JSON.stringify(data)
                });

                if (response.ok) {
                    btn.innerText = 'Success!';
                    btn.style.background = '#00ff80';
                    contactForm.reset();
                    setTimeout(() => {
                        btn.innerText = originalText;
                        btn.style.background = '';
                        btn.disabled = false;
                    }, 3000);
                }
            } catch (error) {
                console.error('Error submitting inquiry:', error);
                btn.innerText = 'Error';
                btn.disabled = false;
            }
        });
    }

    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }

    const sellForm = document.getElementById('sell-form');
    if (sellForm) {
        sellForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = sellForm.querySelector('button[type="submit"]');
            const originalText = btn.innerText;

            const formData = new FormData(sellForm);
            const data = Object.fromEntries(formData.entries());

            btn.disabled = true;
            btn.innerText = 'Posting...';

            try {
                const response = await fetch(`${API_BASE}/bikes/`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': getCookie('csrftoken')
                    },
                    body: JSON.stringify(data)
                });

                if (response.ok) {
                    btn.innerText = 'Listing Live!';
                    btn.style.background = '#00ff80';
                    sellForm.reset();
                    setTimeout(() => {
                        window.location.href = '/inventory.html';
                    }, 2000);
                }
            } catch (error) {
                console.error('Error posting bike:', error);
                btn.innerText = 'Error';
                btn.disabled = false;
            }
        });
    }

    // Admin/UI Logic
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            localStorage.setItem('admin_logged_in', 'true');
            window.location.href = '/admin/';
        });
    }

    // Logout Functionality
    const logoutBtn = document.querySelector('a.btn-outline[href="/"]');
    if (logoutBtn && window.location.pathname.includes('admin')) {
        logoutBtn.addEventListener('click', (e) => {
            localStorage.removeItem('admin_logged_in');
        });
    }

    if (window.location.pathname.includes('admin.html')) {
        if (!localStorage.getItem('admin_logged_in')) {
            window.location.href = 'admin-auth.html';
        }
    }
});
